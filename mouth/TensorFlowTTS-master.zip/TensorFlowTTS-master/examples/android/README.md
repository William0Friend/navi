### Android Demo

This is a simple Android demo which will load converted FastSpeech2 and Multi-Band MelGAN modules to synthesize audio.
In order to optimize the synthesize speed, two LinkedBlockingQueues have been implemented.


### HOW-TO
1. Import this project into Android Studio.
2. Run the app!

### LICENSE
 The license use for this code is [CC BY-NC 3.0](https://creativecommons.org/licenses/by-nc/3.0/). Please read the license carefully before you use it.

### Contributors
[Xuefeng Ding](https://github.com/mapledxf)
