#!/bin/bash
docker build --rm -t tftts -f examples/fastspeech2_libritts/scripts/docker/Dockerfile .
