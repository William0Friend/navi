//
//  TF_TTS_DemoApp.swift
//  TF TTS Demo
//
//  Created by 안창범 on 2021/03/16.
//

import SwiftUI

@main
struct TF_TTS_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
