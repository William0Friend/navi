# Speaker Manager API

The {class}`TTS.tts.utils.speakers.SpeakerManager` organize speaker related data and information for 🐸TTS models. It is
especially useful for multi-speaker models.


## Speaker Manager
```{eval-rst}
.. automodule:: TTS.tts.utils.speakers
    :members:
```