## Prerequisites
* [ ] Did you make sure a similar [issue](../) didn't exist?
* [ ] Did you update gTTS to the latest? (`pip install --upgrade gTTS`)

## Proposed Behaviour
<!--- Tell us what should happen -->
<!--- Please use code blocks when pasting code or stack traces  -->
```
code
```

## Context
<!--- How has this issue affected you? What are you trying to accomplish? -->
<!--- Providing context helps us come up with a solution that is most useful in the real world -->
<!--- Add anything useful here! -->
