## Prerequisites
* [ ] Did you make sure a similar [issue](../) didn't exist?
* [ ] Did you update gTTS to the latest? (`pip install --upgrade gTTS`)

## Current Behaviour (steps to reproduce)
<!--- Tell us what happens instead of the expected behavior -->
<!--- Please use code blocks when pasting code or stack traces  -->
```
code
```

## Expected Behaviour
<!--- Tell us what should happen -->
<!--- Please use code blocks when pasting code or stack traces  -->
```
code
```

## Context
<!--- How has this issue affected you? What are you trying to accomplish? -->
<!--- Providing context helps us come up with a solution that is most useful in the real world -->
<!--- Add anything useful here! -->

## Environment
<!--- Include as many relevant details about the environment you experienced the bug in -->
* gTTS version:
* Operating System version: