---
name: 'TTS Discourse '
about: Pls consider to use TTS Discourse page.
title: ''
labels: ''
assignees: ''

---
<b>Questions</b> will not be answered here!!

Help is much more valuable if it's shared publicly, so that more people can benefit from it.

Please consider posting on [TTS Discourse](https://discourse.mozilla.org/c/tts) page or matrix [chat room](https://matrix.to/#/!KTePhNahjgiVumkqca:matrix.org?via=matrix.org) if your issue is not directly related to TTS development (Bugs, code updates etc.).

You can also check https://github.com/mozilla/TTS/wiki/FAQ for common questions and answers.

Happy posting!

https://discourse.mozilla.org/c/tts
